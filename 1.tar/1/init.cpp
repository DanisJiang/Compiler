#include "global.hpp"

void init()
{
    insert("div", DIV);
    insert("mod", MOD);
    insert("", 0);
}