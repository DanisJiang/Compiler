#include "global.hpp"

int main()
{
    init();
    parse();
    return 0;
}