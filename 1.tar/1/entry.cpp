#include "global.hpp"

const std::string &entry::getLex()
{
    return lex;
}